
import RPi.GPIO as GPIO
import logging
from lib_nrf24 import NRF24
import time
import spidev
logging.basicConfig(format='%(asctime)s %(levelname)-8s %(message)s', level=logging.INFO,datefmt='%Y-%m-%d %H:%M:%S')

GPIO.setmode(GPIO.BCM)

pipes = [[0xE8, 0xE8, 0xF0, 0xF0, 0xE1], [0xF0, 0xF0, 0xF0, 0xF0, 0xE1]]


radio = NRF24(GPIO, spidev.SpiDev())
radio.begin(0, 25)
radio.setPayloadSize(32)
radio.setChannel(0x64)

radio.setDataRate(NRF24.BR_1MBPS)
radio.setPALevel(NRF24.PA_MIN)

radio.setAutoAck(True)
radio.enableDynamicPayloads()
radio.enableAckPayload()

radio.openReadingPipe(1, pipes[1])
radio.printDetails()

radio.startListening()
if not radio.isPVariant():
    # If radio configures correctly, we confirmed a "plus" (ie "variant") nrf24l01+
    # Else print diagnostic stuff & exit.
    radio.printDetails()
    # (or we could always just print details anyway, even on good setup, for debugging)
    print ("NRF24L01+ not found.")
    exit()
while(1):
    while not radio.available():
        time.sleep(1 / 100)
    receivedMessage = []
    radio.read(receivedMessage, radio.getDynamicPayloadSize())
   
    
    ak = [ord(c) for c in "got it"]
    radio.writeAckPayload(1, receivedMessage, len(receivedMessage))

    #print("Translating the receivedMessage into unicode characters")
    string = ""
    for n in receivedMessage:
        # Decode into standard unicode set
        if (n >= 32 and n <= 126):
            string += chr(n)

    print(string)
    #radio.writeAckPayload(1, ackPL, len(ackPL))
    #print("Loaded payload reply of {}".format(ackPL))
