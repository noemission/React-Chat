const spawn = require('child_process').spawn;
const mqtt = require('mqtt')
const client = mqtt.connect('mqtt://localhost:1883')

const proc = spawn('python3', ['-u', 'receivePy.py'])
const log = console.log

console.log = (...args) => {
 const now=(new Date()).toLocaleDateString('el-GR',
	{
		hour12: false,
		hour:'2-digit',
		minute: '2-digit',
		second: '2-digit'
	})
	log(now,args)
}

client.on('connect', function () {
    console.log('connected to mqtt')
})


const publishDoorSensor = (state, battery) => {
    client.publish('stat/front_door/STATE', state === 1 ? 'ON' : 'OFF', { retain: true })
    client.publish('stat/front_door/BATTERY', '' + battery, { retain: true })
}

const publishEnvironmentSensor = (brightness, humidity, temperature, battery) => {
    brightness && client.publish('stat/environment_sensor/BRIGHTNESS', brightness.toString(), { retain: true })
    humidity && client.publish('stat/environment_sensor/HUMIDITY', humidity.toString(), { retain: true })
    temperature && client.publish('stat/environment_sensor/TEMPERATURE', temperature.toString(), { retain: true })
    battery && client.publish('stat/environment_sensor/BATTERY', battery.toString(), { retain: true })
}

const handleData = (data) => {
    if (data.id) {
        switch (data.id) {
            case 2:
                console.log('publishing env sensor', data)
                publishEnvironmentSensor(data.brig, data.hum, data.temp, data.bat)
                break;
            default:
                break;
        }
    } else {
        publishDoorSensor(data.sensor, data.bat)
    }
}

proc.stdout.on('data', (data) => {
    console.log(`stdout: ${data.toString().trim()}`);
    try {
        handleData(JSON.parse(data.toString().trim()));
    } catch (error) {
        console.error(error);
    }
});

proc.stderr.on('data', (data) => {
    console.error(`stderr: ${data}`);
});

proc.on('close', (code) => {
    console.log(`child process exited with code ${code}`);
});


