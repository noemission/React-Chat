import sys
import RPi.GPIO as GPIO
import logging
from lib_nrf24 import NRF24
import time
import spidev
logging.basicConfig(format='%(asctime)s %(levelname)-8s %(message)s', level=logging.INFO,datefmt='%Y-%m-%d %H:%M:%S')

GPIO.setmode(GPIO.BCM)

def read_in():
    return input('What is your name?')
pipes = [[0xE8, 0xE8, 0xF0, 0xF0, 0xE1], [0xF0, 0xF0, 0xF0, 0xF0, 0xE1]]

radio = NRF24(GPIO, spidev.SpiDev())
radio.begin(0, 17)
radio.setPayloadSize(32)
radio.setChannel(0x64)

radio.setDataRate(NRF24.BR_1MBPS)
radio.setPALevel(NRF24.PA_MIN)
#radio.setAutoAck(True)
radio.enableDynamicPayloads()
#radio.enableAckPayload()

radio.openWritingPipe(pipes[0])
radio.printDetails()

radio.startListening()
radio.stopListening()
if not radio.isPVariant():
    # If radio configures correctly, we confirmed a "plus" (ie "variant") nrf24l01+
    # Else print diagnostic stuff & exit.
    radio.printDetails()
    # (or we could always just print details anyway, even on good setup, for debugging)
    print ("NRF24L01+ not found.")
    exit()
while(1):
    radio.write(list(read_in()))
    #radio.write("0xE0E040BF")
    print("Sending!")
    time.sleep(1)
